//
//  TableViewCell.swift
//  collection in tablecell with page control
//
//  Created by Mac on 14/04/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var collection: UICollectionView!
 }


