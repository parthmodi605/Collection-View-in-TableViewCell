//
//  CollectionViewCell.swift
//  collection in tablecell with page control
//
//  Created by Mac on 14/04/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img1: UIImageView!
    
    @IBOutlet weak var lbl1: UILabel!
    
    
}
